﻿namespace fourInARow
{
    partial class GameForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.levelToolStripMenuItem = new System.Windows.Forms.ToolStripComboBox();
            this.elementToolStripComboBox = new System.Windows.Forms.ToolStripComboBox();
            this.modeToolStripMenuItem = new System.Windows.Forms.ToolStripComboBox();
            this.undoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.playerOneColorToolStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.playerTwoColorToolStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.colorDialogPlayer1 = new System.Windows.Forms.ColorDialog();
            this.playerOneColorDisplay = new System.Windows.Forms.Button();
            this.playButton = new System.Windows.Forms.Button();
            this.playerTwoColorDisplay = new System.Windows.Forms.Button();
            this.colorDialogPlayer2 = new System.Windows.Forms.ColorDialog();
            this.playerOneLabel = new System.Windows.Forms.Label();
            this.playerTwoLabel = new System.Windows.Forms.Label();
            this.gameStateTextBox = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 472);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Goodluck";
            this.label1.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 444);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Welcome";
            this.label2.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 500);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Have Fun";
            this.label3.Visible = false;
            // 
            // levelToolStripMenuItem
            // 
            this.levelToolStripMenuItem.Items.AddRange(new object[] {
            "Easy",
            "Hard",
            "Don\'t even try"});
            this.levelToolStripMenuItem.Name = "levelToolStripMenuItem";
            this.levelToolStripMenuItem.Size = new System.Drawing.Size(110, 33);
            this.levelToolStripMenuItem.Text = "Level";
            this.levelToolStripMenuItem.SelectedIndexChanged += new System.EventHandler(this.levelToolStripMenuItem_SelectedIndexChanged);
            // 
            // elementToolStripComboBox
            // 
            this.elementToolStripComboBox.Items.AddRange(new object[] {
            "MiniMax",
            "AplhaBeta"});
            this.elementToolStripComboBox.Name = "elementToolStripComboBox";
            this.elementToolStripComboBox.Size = new System.Drawing.Size(110, 33);
            this.elementToolStripComboBox.Text = "Element";
            this.elementToolStripComboBox.SelectedIndexChanged += new System.EventHandler(this.ElementToolStripComboBox_SelectedIndexChanged_1);
            // 
            // modeToolStripMenuItem
            // 
            this.modeToolStripMenuItem.Items.AddRange(new object[] {
            "P v P",
            "P v AI"});
            this.modeToolStripMenuItem.Name = "modeToolStripMenuItem";
            this.modeToolStripMenuItem.Size = new System.Drawing.Size(110, 33);
            this.modeToolStripMenuItem.Text = "Mode";
            this.modeToolStripMenuItem.SelectedIndexChanged += new System.EventHandler(this.modeToolStripMenuItem_SelectedIndexChanged);
            // 
            // undoToolStripMenuItem
            // 
            this.undoToolStripMenuItem.Name = "undoToolStripMenuItem";
            this.undoToolStripMenuItem.Size = new System.Drawing.Size(72, 33);
            this.undoToolStripMenuItem.Text = "Undo";
            this.undoToolStripMenuItem.Click += new System.EventHandler(this.undoToolStripMenuItem_Click);
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            this.resetToolStripMenuItem.Size = new System.Drawing.Size(70, 33);
            this.resetToolStripMenuItem.Text = "Reset";
            this.resetToolStripMenuItem.Click += new System.EventHandler(this.resetToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.modeToolStripMenuItem,
            this.levelToolStripMenuItem,
            this.elementToolStripComboBox,
            this.undoToolStripMenuItem,
            this.resetToolStripMenuItem,
            this.playerOneColorToolStrip,
            this.playerTwoColorToolStrip});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(9, 3, 0, 3);
            this.menuStrip1.Size = new System.Drawing.Size(930, 39);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // playerOneColorToolStrip
            // 
            this.playerOneColorToolStrip.Enabled = false;
            this.playerOneColorToolStrip.Name = "playerOneColorToolStrip";
            this.playerOneColorToolStrip.Size = new System.Drawing.Size(138, 33);
            this.playerOneColorToolStrip.Text = "Player 1 Color";
            this.playerOneColorToolStrip.Click += new System.EventHandler(this.PlayerOneColorToolStrip_Click);
            // 
            // playerTwoColorToolStrip
            // 
            this.playerTwoColorToolStrip.Enabled = false;
            this.playerTwoColorToolStrip.Name = "playerTwoColorToolStrip";
            this.playerTwoColorToolStrip.Size = new System.Drawing.Size(138, 33);
            this.playerTwoColorToolStrip.Text = "Player 2 Color";
            this.playerTwoColorToolStrip.Click += new System.EventHandler(this.Player2ColorToolStripMenuItem_Click);
            // 
            // colorDialogPlayer1
            // 
            this.colorDialogPlayer1.SolidColorOnly = true;
            // 
            // playerOneColorDisplay
            // 
            this.playerOneColorDisplay.BackColor = System.Drawing.Color.Red;
            this.playerOneColorDisplay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.playerOneColorDisplay.Location = new System.Drawing.Point(605, 114);
            this.playerOneColorDisplay.Name = "playerOneColorDisplay";
            this.playerOneColorDisplay.Size = new System.Drawing.Size(75, 75);
            this.playerOneColorDisplay.TabIndex = 5;
            this.playerOneColorDisplay.UseVisualStyleBackColor = false;
            // 
            // playButton
            // 
            this.playButton.BackColor = System.Drawing.Color.White;
            this.playButton.Enabled = false;
            this.playButton.Location = new System.Drawing.Point(784, 1);
            this.playButton.Name = "playButton";
            this.playButton.Size = new System.Drawing.Size(80, 34);
            this.playButton.TabIndex = 6;
            this.playButton.Text = "Play";
            this.playButton.UseVisualStyleBackColor = false;
            this.playButton.Click += new System.EventHandler(this.SetColorButton_Click);
            // 
            // playerTwoColorDisplay
            // 
            this.playerTwoColorDisplay.BackColor = System.Drawing.Color.Yellow;
            this.playerTwoColorDisplay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.playerTwoColorDisplay.Location = new System.Drawing.Point(770, 114);
            this.playerTwoColorDisplay.Name = "playerTwoColorDisplay";
            this.playerTwoColorDisplay.Size = new System.Drawing.Size(75, 75);
            this.playerTwoColorDisplay.TabIndex = 7;
            this.playerTwoColorDisplay.UseVisualStyleBackColor = false;
            // 
            // playerOneLabel
            // 
            this.playerOneLabel.AutoSize = true;
            this.playerOneLabel.Location = new System.Drawing.Point(601, 79);
            this.playerOneLabel.Name = "playerOneLabel";
            this.playerOneLabel.Size = new System.Drawing.Size(86, 20);
            this.playerOneLabel.TabIndex = 8;
            this.playerOneLabel.Text = "Player One";
            // 
            // playerTwoLabel
            // 
            this.playerTwoLabel.AutoSize = true;
            this.playerTwoLabel.Location = new System.Drawing.Point(759, 79);
            this.playerTwoLabel.Name = "playerTwoLabel";
            this.playerTwoLabel.Size = new System.Drawing.Size(85, 20);
            this.playerTwoLabel.TabIndex = 9;
            this.playerTwoLabel.Text = "Player Two";
            // 
            // gameStateTextBox
            // 
            this.gameStateTextBox.BackColor = System.Drawing.Color.White;
            this.gameStateTextBox.Location = new System.Drawing.Point(579, 218);
            this.gameStateTextBox.Multiline = true;
            this.gameStateTextBox.Name = "gameStateTextBox";
            this.gameStateTextBox.Size = new System.Drawing.Size(294, 352);
            this.gameStateTextBox.TabIndex = 10;
            this.gameStateTextBox.TextChanged += new System.EventHandler(this.GameStateTextBox_TextChanged);
            // 
            // GameForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(930, 612);
            this.Controls.Add(this.gameStateTextBox);
            this.Controls.Add(this.playerTwoLabel);
            this.Controls.Add(this.playerOneLabel);
            this.Controls.Add(this.playerTwoColorDisplay);
            this.Controls.Add(this.playButton);
            this.Controls.Add(this.playerOneColorDisplay);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "GameForm";
            this.Text = "Connect four in a row";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.GameForm_Paint);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.GameForm_MouseClick);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStripComboBox levelToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox elementToolStripComboBox;
        private System.Windows.Forms.ToolStripComboBox modeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem undoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ColorDialog colorDialogPlayer1;
        private System.Windows.Forms.ToolStripMenuItem playerTwoColorToolStrip;
        private System.Windows.Forms.Button playerOneColorDisplay;
        private System.Windows.Forms.Button playButton;
        private System.Windows.Forms.ToolStripMenuItem playerOneColorToolStrip;
        private System.Windows.Forms.Button playerTwoColorDisplay;
        private System.Windows.Forms.ColorDialog colorDialogPlayer2;
        private System.Windows.Forms.Label playerOneLabel;
        private System.Windows.Forms.Label playerTwoLabel;
        private System.Windows.Forms.TextBox gameStateTextBox;
    }
}

